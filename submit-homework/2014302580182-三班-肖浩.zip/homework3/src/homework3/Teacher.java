package homework3;

import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;
import org.jsoup.select.Elements;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.FileWriter;
import java.io.IOException;
import java.io.OutputStreamWriter;

public class Teacher {
public static void main(String[] args)throws IOException {
		
	    try{
	    Document doc = Jsoup.connect("http://staff.whu.edu.cn/show.jsp?lang=cn&n=Chen%20Beibei").get();
	    //�������ʽ
	    Elements elements1 = doc.select("div[class~=^details col-md-10 col-sm-9 col-xs-7]");
	    
	    //��ȡ��ʦ����
	    Elements elements2 = elements1.select("h3");
	    String teacher=elements2.get(0).text();
	    System.out.println(teacher);
	    
	    //��ȡ��ʦ�绰������
	    Elements elements3=elements1.select("p");
	    String news=elements3.get(0).text();
	    System.out.println(news);
	    
	    //��ȡ��ʦ���
	    Elements elements4=doc.select("[class=details col-md-12 col-sm-12 col-xs-12]");
	    Elements elements5=elements4.select("p");
	    String summary=elements4.get(0).text();
	    System.out.println(summary);
	    
	    //�����txt
	    File fileout = new File("teacher.txt");
	    OutputStreamWriter osr = new OutputStreamWriter(new FileOutputStream(fileout), "UTF-8");
	    BufferedWriter br = new BufferedWriter(osr);
	    br.write(teacher);
	    br.newLine();
	    br.write(news);
	    br.newLine();
	    br.write(summary);
	    br.flush();//ˢ�� 
	    br.close();//�ر���
		}catch (IOException e) {
			e.printStackTrace();}
	    
	    
	    
	    

    }
    

}
